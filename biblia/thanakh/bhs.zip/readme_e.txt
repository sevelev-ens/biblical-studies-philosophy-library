     Old Testament in Hebrew
(BHS 4th ed. Hebrew Old Testament)

     Install font bwhebb.ttf into System.
     Select text you need and set font bwhebb.

==========================================
Abbreviations:
1. The Name of Book
2. Usuall abbreviation
3. Abbreviation in the file

   1                 2                 3
Genesis             Gen.              Gen
Exodus              Exod.             Exo
Leviticus           Lev.              Lev
Numbers             Num.              Num
Deuteronomy         Deut.             Deu
Joshua              Jos.              Jos
Judges              Jdg.              Jdg
1 Samuel           1 Sam.             1Sa
2 Samuel           2 Sam.             2Sa
1 Kings             1 Ki.             1Ki
2 Kings             2 Ki.             2Ki
Isaiah              Isa.              Isa
Jeremiah            Jer.              Jer
Ezekiel             Ezek.             Eze
Hosea               Hos.              Hos
Joel                Joel              Joe
Amos                Amos              Amo
Obadiah             Obad.             Oba
Jonah               Jon.              Jon
Micah               Mic.              Mic
Nahum               Nah.              Nah
Habakkuk            Hab.              Hab
Zephaniah           Zeph.             Zep
Haggai              Hag.              Hag
Zechariah           Zech.             Zec
Malachi             Mal.              Mal
Psalm               Ps.               Psa
Job                 Job               Job
Proverbs            Prov.             Pro
Ruth                Ruth              Rut
Song of Solomon     Cant.             Sol
Ecclesiastes        Eccl.             Ecc
Lamentations        Lam.              Lam
Ester               Est.              Est
Daniel              Dan.              Dan
Ezra                Ezr.              Ezr
Nehemiah            Neh.              Neh
1 Chronicles       1 Chr.             1Ch
2 Chronicles       2 Chr.             2Ch
